
%% Script to accomplish Step 3c

clear all
close all
clc

% Uncomment the rosbag with the trajectory you want to plot

%bag = rosbag('sel_01.bag'); % Linear trajectory
%bag = rosbag('sel_02.bag'); % Linear trajectory with Trapezoidal velocity profile
%bag = rosbag('sel_03.bag'); % Linear trajectory with Cubic Polynomial velocity profile
%bag = rosbag('sel_05.bag'); % Circular trajectory with Cubic Polynomial velocity profile
j(1) = select(bag,'Topic','/iiwa/iiwa_joint_1_effort_controller/command');
j(2) = select(bag,'Topic','/iiwa/iiwa_joint_2_effort_controller/command');
j(3) = select(bag,'Topic','/iiwa/iiwa_joint_3_effort_controller/command');
j(4) = select(bag,'Topic','/iiwa/iiwa_joint_4_effort_controller/command');
j(5) = select(bag,'Topic','/iiwa/iiwa_joint_5_effort_controller/command');
j(6) = select(bag,'Topic','/iiwa/iiwa_joint_6_effort_controller/command');
j(7) = select(bag,'Topic','/iiwa/iiwa_joint_7_effort_controller/command');

for i = 1:7
   ej(i) = timeseries(j(i));

   subplot(4,2,i);
   plot(ej(i));
   title(sprintf('Torque at Joint %d', i));
   ylabel('Torque');
end


